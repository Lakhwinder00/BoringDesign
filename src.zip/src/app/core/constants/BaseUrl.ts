export const BaseUrl = {
  url: "https://boringmeter-dev-cloud-run-hxaa36ciia-uc.a.run.app/"
  }
